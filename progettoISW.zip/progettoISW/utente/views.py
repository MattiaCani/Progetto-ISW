# Create your views here.
from django.conf import settings
from django.contrib.auth.decorators import login_required

from . import forms
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import HttpResponse, redirect
from django.shortcuts import render
from utente.forms.auth import LoginForm, SignupForm
from utente.models import Cliente
from django.contrib import messages


def logoutview(request):
    logout(request)
    return redirect('login')


def loginview(request):
    form = forms.auth.LoginForm()
    message = ''
    if request.method == 'POST':
        form = forms.auth.LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                message = f'Ciao {user.username}!'
                return redirect('vetrinaCliente')
            else:
                message = 'Login fallito'
    return render(
        request, 'registration/login.html', context={'form': form, 'message': message})


def signupview(request):
    form = forms.auth.SignupForm()
    if request.method == 'POST':
        form = forms.auth.SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            # auto-login user
            #login(request, user)
            newCliente = Cliente(
                
            )
            return redirect(settings.LOGIN_REDIRECT_URL)
    return render(request, 'registration/signup.html', context={'form': form})


@login_required
def vetrina_clienteview(request):
    return render(request, 'vetrine/vetrinaCliente.html')
