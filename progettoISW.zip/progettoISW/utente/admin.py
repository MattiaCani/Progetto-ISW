from django.contrib import admin
# credenziali superuser
# username: roberta, password: Berdjango

# Register your models here.
from .models import Amministratore, Pagamento, Vetrina, Prodotto, Carrello, Ordine, Cliente, ResocontoVendite, \
    VetrinaAmministratore

admin.site.register(Pagamento)
admin.site.register(Vetrina)
admin.site.register(Prodotto)
admin.site.register(Carrello)
admin.site.register(Ordine)
admin.site.register(Cliente)
admin.site.register(Amministratore)
admin.site.register(VetrinaAmministratore)
admin.site.register(ResocontoVendite)
